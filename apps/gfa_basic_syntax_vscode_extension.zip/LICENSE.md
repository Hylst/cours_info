MIT License

Copyright (c) 2024 Hylst

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHERS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.

---

## Additional Notes

This extension is created for educational and nostalgic purposes, supporting
the GFA BASIC 3.6 programming language used on Atari ST systems.

GFA BASIC was originally created by Frank Ostrowski. This extension is not
affiliated with the original GFA BASIC development team.

For more information about GFA BASIC:
- Original GFA BASIC: https://gfabasic.net/
- Frank Ostrowski: https://gfabasic.net/htm/gfa_fo.htm
- GBE (GFA BASIC Editor): https://gfabasic.net/htm/gbe_faq.htm

The extension is provided free of charge for the retro programming community
and Atari ST enthusiasts.