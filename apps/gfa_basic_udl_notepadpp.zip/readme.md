# GFA BASIC 3.6 Atari - Notepad++ User Defined Language (UDL)

Ce fichier UDL (User Defined Language) permet la coloration syntaxique du langage GFA BASIC 3.6 pour Atari ST dans Notepad++.

## Installation

1. **Ouvrir Notepad++**
2. **Aller dans le menu** : `Langage` → `Définir votre langage...`
3. **Cliquer sur "Importer"**
4. **Sélectionner le fichier** `GFABASIC_NotepadStyle.xml`
5. **Redémarrer Notepad++**

## Utilisation

1. **Ouvrir un fichier GFA BASIC** (extensions `.gfa`, `.lst`)
2. **Sélectionner le langage** : `Langage` → `GFA BASIC 3.6 Atari`
3. **La coloration syntaxique s'applique automatiquement**

## Fonctionnalités

### Coloration Syntaxique

- **Commentaires** (vert) : `'`, `REM`, `!`
- **Nombres** (orange) : décimaux, hexadécimaux (`&H`), binaires (`&X`)
- **Chaînes** (violet) : texte entre guillemets
- **Opérateurs** (rouge gras) : `+`, `-`, `*`, `/`, `=`, `<>`, `AND`, `OR`, etc.

### Catégories de Mots-clés

#### Keywords1 (Bleu gras) - Commandes de base
- **Structures de contrôle** : `IF`, `FOR`, `WHILE`, `SELECT`, `PROCEDURE`, `FUNCTION`
- **Commandes de base** : `PRINT`, `INPUT`, `READ`, `DATA`, `LOAD`, `SAVE`
- **Fonctions chaînes** : `LEFT$`, `RIGHT$`, `MID$`, `CHR$`, `ASC`, `STR$`, `VAL`
- **Fonctions mathématiques** : `ABS`, `SIN`, `COS`, `TAN`, `LOG`, `SQR`, `INT`

#### Keywords2 (Violet) - Graphiques et interface
- **Primitives graphiques** : `BOX`, `PBOX`, `CIRCLE`, `ELLIPSE`, `LINE`, `PSET`
- **Graphiques avancés** : `BITBLT`, `SPRITE`, `CLIP`, `VSYNC`
- **Configuration graphique** : `DEFLINE`, `DEFFILL`, `DEFMARK`, `DEFTEXT`
- **Interface GEM** : `ALERT`, `FILESELECT`, `MENU_BAR`, `WIND_CREATE`

#### Keywords3 (Rose) - Système et mémoire
- **Appels système** : `BIOS`, `XBIOS`, `GEMDOS`, `TRAP`
- **Gestion mémoire** : `MALLOC`, `MFREE`, `PEEK`, `POKE`, `DPEEK`, `DPOKE`
- **Fichiers** : `FOPEN`, `FCLOSE`, `FREAD`, `FWRITE`, `FSFIRST`, `FSNEXT`
- **Son** : `SOUND`, `WAVE`, `BEEP`, `DOSOUND`
- **Manipulation bits** : `BSET`, `BCLR`, `BCHG`, `SHL`, `SHR`

#### Keywords4 (Bleu clair) - Entrées/Sorties et contrôle
- **Souris** : `MOUSE`, `MOUSEX`, `MOUSEY`, `MOUSEK`, `SETMOUSE`
- **Clavier** : `INKEY$`, `KEYPRESS`, `KEYGET`, `KEYTEST`
- **Joystick** : `STICK`, `STRIG`, `PADDLE`
- **Fichiers** : `OPEN`, `CLOSE`, `INPUT$`, `LINE INPUT`
- **Événements** : `ON MENU`, `ON ERROR`, `EVERY`, `AFTER`

#### Keywords5 (Violet gras) - Mathématiques avancées
- **Fonctions mathématiques** : `MIN`, `MAX`, `MOD`, `DIV`, `RANDOM`
- **Trigonométrie** : `SINH`, `COSH`, `TANH`, `DEG`, `RAD`, `ATN2`
- **Conversion** : `CINT`, `CLNG`, `CDBL`, `CSNG`, `CVS`, `CVD`
- **Matrices** : `MAT`, `ADD`, `SUB`, `MUL`, `TRANSPOSE`, `IDENTITY`
- **Tableaux** : `LBOUND`, `UBOUND`, `ARRAYSIZE`, `SORT`, `QSORT`

#### Keywords6 (Sarcelle) - AES/VDI avancé
- **AES complet** : toutes les fonctions Application Environment Services
- **VDI complet** : toutes les fonctions Virtual Device Interface
- **Gestion fenêtres** : `WIND_*`, `FORM_*`, `MENU_*`, `OBJC_*`
- **Ressources** : `RSRC_*`, `SCRP_*`, `SHEL_*`, `APPL_*`
- **Événements** : `EVNT_*`

#### Keywords7 (Olive) - Gestion mémoire avancée
- **Allocation** : `ALLOC`, `REALLOC`, `CALLOC`, `MALLOC`, `MFREE`
- **Manipulation** : `MEMSET`, `MEMCPY`, `MEMMOVE`, `MEMCMP`
- **Pointeurs** : `VARPTR`, `SADD`, `STRPTR`, `ARRPTR`
- **Types** : `DEFWRD`, `DEFINT`, `DEFSTR`, `DEFBYT`, `DEFBOOL`
- **Portée** : `LOCAL`, `GLOBAL`, `STATIC`, `SHARED`

#### Keywords8 (Rouge-orange gras) - Constantes et types
- **Booléens** : `TRUE`, `FALSE`, `NULL`
- **Mathématiques** : `PI`, `E`, `INFINITY`, `NAN`
- **Limites** : `MAXINT`, `MININT`, `MAXLNG`, `MINLNG`
- **Types de données** : `INTEGER`, `LONG`, `BYTE`, `BOOLEAN`, `STRING`

### Pliage de Code

Le fichier UDL supporte le pliage (folding) pour :
- **Procédures** : `PROCEDURE` ... `ENDPROC`
- **Fonctions** : `FUNCTION` ... `ENDFUNC`
- **Conditions** : `IF` ... `ENDIF`
- **Boucles** : `FOR` ... `NEXT`, `WHILE` ... `WEND`
- **Sélections** : `SELECT` ... `ENDSELECT`
- **Répétitions** : `REPEAT` ... `UNTIL`

### Formats de Nombres Supportés

- **Décimal** : `123`, `456.789`
- **Hexadécimal** : `&HFF00`, `&H8000`
- **Binaire** : `&X11110000`, `&X01010101`
- **Suffixes de variables** :
  - `$` : chaîne de caractères
  - `%` : entier 32 bits
  - `&` : entier 16 bits
  - `!` : booléen
  - `|` : entier 8 bits

## Améliorations par rapport à la version précédente

### Nouveaux mots-clés ajoutés

1. **Fonctions chaînes avancées** : `UPPER$`, `LOWER$`, `LTRIM$`, `RTRIM$`, `TRIM$`, `REVERSE$`, `REPLACE$`
2. **Gestion fichiers** : `FSFIRST`, `FSNEXT`, `EXIST`, `LOF`, `TOUCH`, `NAME`, `KILL`
3. **Communication** : `INPMID$`, `INPAUX$`, `RSCONF`
4. **Mathématiques étendues** : `SINQ`, `COSQ`, `LOG10`, `ROUND`, `TRUNC`, `FRAC`
5. **Manipulation bits** : `BCLR`, `BSET`, `BCHG`, `PRED`, `SUCC`, `CARD`
6. **Gestion mémoire** : `BLOAD`, `BSAVE`, `STORE`, `RECALL`, `MALLOC`, `MFREE`
7. **Son avancé** : `DMASOUND`, `DMACONTROL`, `SETBUFFER`, `BUFFOPER`
8. **VDI complet** : toutes les fonctions V_*, VST_*, VSL_*, VSF_*, VSM_*, VQ_*
9. **Matrices** : `MAT`, `NORM`, `DET`, `QDET`, `RANG`, `INV`, `TRANSPOSE`
10. **Types et constantes** : `MAXINT`, `MININT`, `INFINITY`, `NAN`

### Améliorations de la structure UDL

#### Support des types de variables amélioré
- **Suffixes primaires** : `$` (chaîne), `%` (entier 32 bits), `&` (entier 16 bits), `!` (booléen), `|` (entier 8 bits)
- **Suffixes secondaires** : `F` (float), `D` (double), `L` (long), `I` (integer), `S` (string), `B` (byte)

#### Pliage de code étendu <mcreference link="https://npp-user-manual.org/docs/user-defined-language-system/" index="1">1</mcreference>
- **Folding in Code 1** : Structures de contrôle principales (IF/ENDIF, FOR/NEXT, WHILE/WEND, etc.)
- **Folding in Code 2** : Délimiteurs de blocs (`{}`, `[]`, `()`) pour une meilleure organisation du code
- **Folding in Comment** : Support des commentaires pliables avec `REM`, `'`, et `!`

#### Délimiteurs améliorés
- **Chaînes de caractères** : Guillemets doubles (`"`) et simples (`'`)
- **Parenthèses et crochets** : `()`, `[]`, `{}` pour une meilleure structuration visuelle
- **Commentaires** : Support des délimiteurs de commentaires dans la coloration

### Organisation améliorée

Les mots-clés sont maintenant organisés par catégories logiques :
- **Keywords1** : Commandes de base et structures de contrôle
- **Keywords2** : Graphiques et interface utilisateur
- **Keywords3** : Système, mémoire et fichiers
- **Keywords4** : Entrées/sorties et gestion d'événements
- **Keywords5** : Mathématiques et manipulation de données
- **Keywords6** : AES/VDI complet
- **Keywords7** : Gestion mémoire avancée
- **Keywords8** : Constantes et types de données

## Sources de référence

Ce fichier UDL a été créé en utilisant les sources suivantes :
- **LANGUAGE_ANALYSIS.md** : Analyse détaillée du langage GFA BASIC
- **gfa_bases.md** : Fondamentaux et programmation de jeux
- **gfamanual.txt** : Manuel de référence officiel GFA BASIC 3.5
- **GFAXPERT.txt** : Guide expert "Your Second GFA-BASIC 3.0 Manual"
- **gfabasic.tmLanguage.json** : Grammaire TextMate pour VS Code

## Compatibilité

- **Notepad++** : Version 7.0 et supérieure
- **Extensions de fichiers** : `.gfa`, `.lst`
- **Encodage** : UTF-8, ANSI, Windows-1252

## Support

Pour signaler des problèmes ou suggérer des améliorations :
1. Vérifiez que le fichier UDL est correctement importé
2. Redémarrez Notepad++ après l'import
3. Assurez-vous que l'extension de fichier est reconnue

## Historique des versions

### Version 2.1.1 (Décembre 2024) - Corrections et améliorations
- **Correction des structures de contrôle** : Ajout du mot-clé `LOOP` manquant pour les structures `DO/LOOP`
- Support étendu des types de variables avec suffixes secondaires
- Pliage de code amélioré avec support des délimiteurs
- Commentaires pliables (REM, ', !)
- Délimiteurs étendus pour parenthèses, crochets et accolades
- Intégration des instructions graphiques supplémentaires
- Documentation basée sur la recherche web officielle Notepad++

### Version 2.1 (Décembre 2024) - Améliorations structurelles
- Améliorations structurelles initiales avec types de variables et pliage

### Version 2.0 (Décembre 2024)
- Ajout de plus de 200 nouveaux mots-clés
- Réorganisation par catégories logiques
- Support complet AES/VDI
- Fonctions mathématiques étendues
- Gestion mémoire avancée
- Documentation complète

### Version 1.0 (Initial)
- Support de base GFA BASIC 3.6
- Coloration syntaxique fondamentale
- Pliage de code basique

---

**Créé par** : Assistant IA basé sur l'analyse des documents de référence GFA BASIC  
**Licence** : Libre d'utilisation pour la communauté Atari ST  
**Dernière mise à jour** : Décembre 2024